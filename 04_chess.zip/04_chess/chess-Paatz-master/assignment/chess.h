/*----------------------------------------------------------
 *				HTBLA-Leonding / Klasse: 2AHDV
 * ---------------------------------------------------------
 * Exercise Number: 0
 * Title:			chess.h
 * Author:			P. Bauer
 * Due Date:		October 15, 2014
 * ----------------------------------------------------------
 * Description:
 * Basic chess functions.
 * ----------------------------------------------------------
 */

#ifndef Chess_H
#define  Chess_H

 enum  	PieceType {
  Pawn, Rook, Knight, Bishop,
  Queen, King, NoPiece
};

 /* PieceType beschreibt verschiedene Schachfiguren mit deren englischen Namen. Ein weiterer Typ NoPiece wird dazu verwendet, wenn eine Figur in einem Feld angesprochen werden soll, auf der gar keine Figur steht.

 Enumerator:
 Pawn
 Bauer

 Rook
 Turm

 Knight
 Springer

 Bishop
 Läufer

 Queen
 Dame

 King
 König

 NoPiece
 Keine Figur
 */


 enum  	PieceColor { White, Black };
 enum  	MoveType { NormalMove, CaptureMove };

 /* Art eines Zuges

 Enumerator:
 NormalMove
 Zug bei der KEINE gegnerische Figur geschlagen wird.

 CaptureMove
 Zug bei der eine gegnerische Figur geschlagen wird. */



 struct  	ChessPiece                                 //ChessPiece beschreibt eine Schachfigur.
 {
   enum PieceColor 	color;                            //farbe der Figur
   enum PieceType 	type ;                          //Art der Figur
 };

 struct  	ChessSquare                                //ChessSquare beschreibt ein einzelnes Feld eines Schachbrettes.
 {
   bool 	is_occupied;                               //Ein Feld kann entweder mit einer Figur besetzt sein oder nicht.
   struct ChessPiece 	piece;                         //Wenn das Feld besetzt ist, beschreibt piece die Figur, mit der es besetzt ist.
 };

 typedef struct ChessSquare 	ChessBoard [8][8];     //ChessBoard beschreibt ein Schachbrett und ist eine Matrix von 8 mal 8 ChessSquare.
 typedef char 	File;                                //File bezeichnet eine Spalte eines Schachbrettes und wird mit den Buchstaben 'a' - 'h' identifiziert.
 typedef int 	Rank;                                  //Rank bezeichnet eine Zeile eines Schachbrettes und wird mit den Ziffern '1' - '8' identifiziert.



bool 	is_piece (struct ChessPiece pc, enum PieceColor color, enum PieceType type);
void 	init_chess_board (ChessBoard chess_board);
struct ChessSquare * 	get_square (ChessBoard chess_board, File file, Rank rank);
bool 	is_square_occupied (ChessBoard chess_board, File file, Rank rank);
bool 	add_piece (ChessBoard chess_board, File file, Rank rank, struct ChessPiece piece);
struct ChessPiece 	get_piece (ChessBoard chess_board, File file, Rank rank);
void 	setup_chess_board (ChessBoard chess_board);
bool 	remove_piece (ChessBoard chess_board, File file, Rank rank);
bool 	squares_share_file (File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_rank (File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_diagonal (File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_knights_move (File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_pawns_move (enum PieceColor color, enum MoveType move, File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_queens_move (File s1_f, Rank s1_r, File s2_f, Rank s2_r);
bool 	squares_share_kings_move (File s1_f, Rank s1_r, File s2_f, Rank s2_r);

#endif
